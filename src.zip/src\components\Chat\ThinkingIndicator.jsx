import { useEffect, useState } from "react";
import "./ThinkingIndicator.css";

const messages = [
  "✦ Kyorah está pensando...",
  "✦ Analisando o contexto...",
  "✦ Organizando a melhor resposta...",
  "✦ Quase pronto...",
];

export default function ThinkingIndicator() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((current) =>
        current < messages.length - 1 ? current + 1 : current
      );
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="thinking-indicator">
      <p key={index} className="thinking-text">
        {messages[index]}
      </p>

      <div className="thinking-dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  );
}