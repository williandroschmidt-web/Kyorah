import "./Home.css";

export default function Home() {
  const hour = new Date().getHours();

  let greeting = "Boa noite";

  if (hour >= 5 && hour < 12) greeting = "Bom dia";
  if (hour >= 12 && hour < 18) greeting = "Boa tarde";

  return (
    <section className="home">

      <img
        src="/logo-stella.png"
        alt="Stella"
        className="home-logo"
      />

      <span className="home-greeting">
        {greeting}
      </span>

      <h1>
        Em que posso ajudar hoje?
      </h1>

      <p>
        Inteligência que evolui com você.
      </p>

    </section>
  );
}