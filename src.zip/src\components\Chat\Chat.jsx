import { useEffect, useRef } from "react";
import "./Chat.css";
import Message from "../Message/Message";
import ThinkingIndicator from "./ThinkingIndicator";

export default function Chat({ messages, loading }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, loading]);

  return (
    <main className="chat">
      <div className="messages">

        {messages.map((message) => (
          <Message
            key={message.id}
            message={message}
          />
        ))}

        {loading && (
          <div className="message assistant">
            <ThinkingIndicator />
          </div>
        )}

        <div ref={bottomRef} />

      </div>
    </main>
  );
}