import { useState } from "react";
import "./Layout.css";

import Sidebar from "../Sidebar/Sidebar";
import SidebarToggle from "../Sidebar/SidebarToggle";
import Home from "../Home/Home";
import Chat from "../Chat/Chat";
import Composer from "../Composer/Composer";

export default function Layout({
  messages,
  loading,
  sendMessage,
}) {
  const hasMessages = messages.length > 0;

  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="layout">

      <SidebarToggle
  isOpen={sidebarOpen}
  onClick={() => setSidebarOpen(!sidebarOpen)}
/>

      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {sidebarOpen && (
        <div
          className="sidebar-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <main className="main">

        {hasMessages ? (
          <div className="chat-area">
            <Chat
              messages={messages}
              loading={loading}
            />
          </div>
        ) : (
          <Home />
        )}

        <Composer sendMessage={sendMessage} />

      </main>

    </div>
  );
}