import "./Message.css";

export default function Message({ message }) {
  const isAssistant = message.role === "assistant";

  return (
    <div className={`message ${message.role}`}>

      {isAssistant && (
  <div className="assistant-header">
    <span>Kyorah</span>
  </div>
)}

      <div className="message-content">
        {message.content}
      </div>

    </div>
  );
}