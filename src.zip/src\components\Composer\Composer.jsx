import { useEffect, useRef, useState } from "react";
import "./Composer.css";
import { FiArrowUp, FiPaperclip } from "react-icons/fi";

export default function Composer({ sendMessage }) {
  const [text, setText] = useState("");

  const textareaRef = useRef(null);

  useEffect(() => {
    const textarea = textareaRef.current;

    if (!textarea) return;

    textarea.style.height = "0px";
    textarea.style.height = `${textarea.scrollHeight}px`;
  }, [text]);

  function handleSend() {
    if (!text.trim()) return;

    sendMessage(text);

    setText("");

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <div className="composer-wrapper">
      <div className="composer">

        <button className="icon-button">
          <FiPaperclip />
        </button>

        <textarea
          ref={textareaRef}
          rows={1}
          value={text}
          placeholder="Pergunte qualquer coisa..."
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
        />

        <button
          className="send-button"
          onClick={handleSend}
        >
          <FiArrowUp />
        </button>

      </div>
    </div>
  );
}