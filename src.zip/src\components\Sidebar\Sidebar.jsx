import "./Sidebar.css";

import {
  FiPlus,
  FiMessageSquare,
  FiSettings,
} from "react-icons/fi";

export default function Sidebar({ isOpen, onClose }) {
  return (
    <aside className={`sidebar ${isOpen ? "open" : ""}`}>

      <div>

        <div className="sidebar-logo">

          <div className="logo-box">
            <img
              src="/favicon.png"
              alt="Kyorah Logo"
            />
          </div>

          <div>

            <h1>Kyorah</h1>

            <span>AI Assistant</span>

          </div>

        </div>

        <button className="new-chat">

          <FiPlus />

          <span>Nova conversa</span>

        </button>

        <div className="chat-history">

          <button className="history active">

            <FiMessageSquare />

            <span>Nova conversa</span>

          </button>

          <button className="history">

            <FiMessageSquare />

            <span>Como criar um app?</span>

          </button>

          <button className="history">

            <FiMessageSquare />

            <span>Explicar React</span>

          </button>

        </div>

      </div>

      <div className="sidebar-footer">

        <button className="settings">

          <FiSettings />

          Configurações

        </button>

      </div>

    </aside>
  );
}