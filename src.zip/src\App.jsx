import { useState } from "react";

import Layout from "./components/Layout/Layout";
import { sendMessageToAI } from "./services/api";

function App() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  async function sendMessage(text) {
    if (!text.trim()) return;

    const userMessage = {
      id: Date.now(),
      role: "user",
      content: text,
    };

    setMessages((old) => [...old, userMessage]);

    setLoading(true);

    try {
      const response = await sendMessageToAI(text);

      setMessages((old) => [
        ...old,
        {
          id: Date.now() + 1,
          role: "assistant",
          content: response,
        },
      ]);
    } catch (error) {
      setMessages((old) => [
        ...old,
        {
          id: Date.now() + 1,
          role: "assistant",
          content: `❌ ${error.message}`,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout
      messages={messages}
      loading={loading}
      sendMessage={sendMessage}
    />
  );
}

export default App;